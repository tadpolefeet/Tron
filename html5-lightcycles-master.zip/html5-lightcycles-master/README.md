# lightcycles

My first attempt at ever building a game.  

And my first attempt at really doing something with the canvas element.

So forgive any mistakes ;)

## Installation

It's just HTML, CSS, and javascript.  Open it in a modern browser and have fun.

Too lazy to download?  [Play it on jsfiddle](http://jsfiddle.net/PxpVr/16/embedded/result/).

## Inspiration

When I was a kid I loved to play [the old Tron game](https://www.youtube.com/watch?v=ONg0rUogiEg), so when I decided to make a game to learn the canvas element, this seem fitting.

## Contributing

You can fork/fix/add/pull request this repo, and I'll gladly add your code ;)

## Contributors

If you issue a pull request, add your name here!

## License

MIT License - http://opensource.org/licenses/MIT

Copyright (c) 2013 Jason D. Straughan

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.